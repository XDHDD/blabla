Building Litecoin
================

See doc/build-*.md for instructions on building the various
elements of the Litecoin Core reference implementation of Litecoin.
